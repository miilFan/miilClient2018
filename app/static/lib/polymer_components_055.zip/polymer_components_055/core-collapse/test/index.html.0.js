
    WCT.loadSuites([
      'basic.html'
    ]);
  