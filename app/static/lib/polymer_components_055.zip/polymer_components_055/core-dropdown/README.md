core-dropdown
=============

owner: [@morethanreal](http://github.com/morethanreal)

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-dropdown) for more information.
