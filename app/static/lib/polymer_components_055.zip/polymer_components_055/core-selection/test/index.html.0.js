
    WCT.loadSuites([
      'basic.html',
      'multi.html'
    ]);
  