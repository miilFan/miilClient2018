
    WCT.loadSuites([
      'activate-event.html',
      'basic.html',
      'multi.html',
      'next-previous.html',
      'selected-attr-prop.html',
      'template-repeat.html',
      'content.html'
    ]);
  