
  CoreStyle.g.columns = 3;
