
    WCT.loadSuites([
      'paper-button.html'
    ]);
  