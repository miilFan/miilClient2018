

  Polymer({

    publish: {

      /**
       * @attribute closeSelector
       * @type string
       * @default '[affirmative],[dismissive]'
       */
      closeSelector: '[affirmative],[dismissive]'
    }

  });

