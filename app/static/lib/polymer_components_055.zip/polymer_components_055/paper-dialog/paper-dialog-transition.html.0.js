
  Polymer({
    baseClass: 'paper-dialog-transition'
  });
