

    document.body.addEventListener('change', function(e) {
      console.log('change', e.target);
    });

  