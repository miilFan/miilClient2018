
    WCT.loadSuites([
      'paper-autogrow-textarea.html',
      'paper-input-decorator.html',
      'paper-input.html'
    ]);
  