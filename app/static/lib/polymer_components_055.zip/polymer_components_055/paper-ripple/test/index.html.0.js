
    WCT.loadSuites([
      'position.html'
    ]);
  