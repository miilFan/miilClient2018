

assertInterpolation({
  property: 'object-position',
  from: '50% 50%',
  to: '100% 100%'
}, [
  {at: -0.3, is: '35% 35%'},
  {at: 0, is: '50% 50%'},
  {at: 0.5, is: '75% 75%'},
  {at: 1, is: '100% 100%'},
  {at: 1.5, is: '125% 125%'}
]);

assertInterpolation({
  property: 'object-position',
  from: '100px 200px',
  to: '0px 0px'
}, [
  {at: -0.3, is: '130px 260px'},
  {at: 0, is: '100px 200px'},
  {at: 0.5, is: '50px 100px'},
  {at: 1, is: '0px 0px'},
  {at: 1.5, is: '-50px -100px'}
]);

// Zero seem to be a special case in the old implementation
assertInterpolation({
  property: 'object-position',
  from: '50% 100%',
  to: '0px 0px'
}, [
  {at: -0.3, is: '65% 130%'},
  {at: 0, is: '50% 100%'},
  {at: 0.5, is: '25% 50%'},
  {at: 1, is: '0px 0px'},
  {at: 1.5, is: '-25% -50%'}
]);

assertInterpolation({
  property: 'object-position',
  from: '50% 100%',
  to: '50px 100px'
}, [
  {at: -0.3, is: 'calc(65% + -15px) calc(130% + -30px)'},
  {at: 0, is: '50% 100%'},
  {at: 0.5, is: 'calc(25% + 25px) calc(50% + 50px)'},
  {at: 1, is: '50px 100px'},
  {at: 1.5, is: 'calc(-25% + 75px) calc(-50% + 150px)'}
]);

assertInterpolation({
  property: 'object-position',
  from: 'center',
  to: 'top right'
}, [
  {at: -0.3, is: '35% 65%'},
  {at: 0, is: '50% 50%'},
  {at: 0.5, is: '75% 25%'},
  {at: 1, is: '100% 0%'},
  {at: 1.5, is: '125% -25%'}
]);
