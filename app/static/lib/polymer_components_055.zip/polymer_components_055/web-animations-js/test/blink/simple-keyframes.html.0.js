
test(function() {
  assertAnimationStyles([
    {opacity: '0.25', left: '25px'},
    {opacity: '0.75', left: '75px'},
  ], {
    0.5: {opacity: '0.5', left: '50px'},
  });
},
'element.animate() with 2 keyframes',
{
  help: 'http://dev.w3.org/fxtf/web-animations/#keyframe-animation-effects',
  assert: [
    'element.animate() should start an animation when two keyframes',
    'are provided with matching properties and no offsets specified.',
  ],
  author: 'Alan Cutter',
});

test(function() {
  assertAnimationStyles([
    {opacity: '0', left: '0px'},
    {opacity: '0.25', left: '25px'},
    {opacity: '0.75', left: '75px'},
  ], {
    0.25: {opacity: '0.125', left: '12.5px'},
    0.75: {opacity: '0.5', left: '50px'},
  });
},
'element.animate() with 3 keyframes',
{
  help: 'http://dev.w3.org/fxtf/web-animations/#keyframe-animation-effects',
  assert: [
    'element.animate() should start an animation when three keyframes',
    'are provided with matching properties and no offsets specified.',
    'The keyframes must maintain their ordering and get distributed',
    'correctly.',
  ],
  author: 'Alan Cutter',
});
